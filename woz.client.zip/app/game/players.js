﻿define(['api/datacontext'], function (db) {
    return {
        players: db.players
    }
});