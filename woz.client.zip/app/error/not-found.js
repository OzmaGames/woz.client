﻿define(function () {
    return {};
});